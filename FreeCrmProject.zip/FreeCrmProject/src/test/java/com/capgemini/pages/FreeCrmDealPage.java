package com.capgemini.pages;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import org.openqa.selenium.support.PageFactory;
 
public class FreeCrmDealPage {

	@FindBy(xpath ="//button[text()='Create']")
	WebElement createDealsBtn;

	@FindBy(xpath = "//input[@name='title']")
	WebElement titleName;
	
	@FindBy(xpath ="//textarea[@name='description']" )
	WebElement description;
	
	@FindBy(xpath ="//input[@name='amount']" )
	WebElement amount;
	
	@FindBy(xpath ="//input[@name='commission']" )
	WebElement commission;
	
	@FindBy(css="div[name='stage'][role='listbox']")
    private WebElement stage;
	
    @FindBy(xpath="(//div[@name='stage'])[3]")
    private WebElement qualify;
    
    @FindBy(css="div[name='type'][role='listbox']")
    private WebElement type;
	
    @FindBy(xpath="(//div[@name='type'])[2]")
    private WebElement newType;
    
  
    @FindBy(xpath="//button[contains(.,'Save')]")
    private WebElement save;
    
    @FindBy(xpath = "//span[contains(text(),'Deals')]")
	private WebElement deals;
	
    WebDriver driver;
    
	public FreeCrmDealPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getCreateDealButton() {
		return createDealsBtn;
	}
	
	public WebElement getTitleName() {
		return titleName;
	}

	public WebElement getDescription() {
		return description;
	}
	
	public WebElement getAmountUsd() {
		return amount;
	}
 
	public WebElement getCommissions() {
		return commission;
	}
	
	public WebElement getStages() {
		return stage;
	}
	
	public WebElement getStageDropdown() {
		return qualify;
	}
	
	public WebElement getTypes() {
		return type;
	}
	
	public WebElement getTypeDropdown() {
		return newType;
	}
	
	public WebElement getSaveDeal() {
		return save;
	}

	public WebElement getDealsBtn() {
		return deals;
	}

}
 
