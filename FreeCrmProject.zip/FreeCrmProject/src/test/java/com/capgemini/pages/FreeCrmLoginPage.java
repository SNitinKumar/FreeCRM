package com.capgemini.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FreeCrmLoginPage {

	@FindBy(xpath = "/html[1]/body[1]/div[1]/header[1]/div[1]/nav[1]/div[2]/div[1]/a[1]/span[1]")
	private WebElement start_here;
	
	@FindBy(name = "email")
	private WebElement enter_email;
	
	@FindBy(name = "password")
	private WebElement enter_password;
	
	@FindBy(xpath = "//div[contains(@class,'ui fluid large blue submit button')]")
	private WebElement login_btn;
	
	@FindBy(xpath = "//div/a/i[@class='money icon']")
	private WebElement dealsLink;
	
	WebDriver driver;
	
	public FreeCrmLoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getLoginPage() {
		return start_here;
	}
	
	public WebElement getEmail() {
		return enter_email;
	}
	
	public WebElement getPassword() {
		return enter_password;
	}
	
	public WebElement getLoginBtn() {
		return login_btn;
	}
	public WebElement getDealsLink() {
		return dealsLink;
	}
}
