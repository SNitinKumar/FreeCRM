package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FreeCrmEditPage {
    WebDriver driver;
    WebDriverWait wait;

    @FindBy(xpath="(//button//i[@class='edit icon'])[2]")
    private WebElement editButton;

    @FindBy(xpath = "//input[@name='title']")
    private WebElement titleField;

    @FindBy(xpath ="//textarea[@name='description']")
    private WebElement descriptionField;

    @FindBy(xpath ="//input[@name='amount']")
    private WebElement amountField;

    @FindBy(xpath ="//input[@name='commission']")
    private WebElement commissionField;

    @FindBy(xpath="//button[contains(.,'Save')]")
    private WebElement saveButton;
    

    public FreeCrmEditPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public WebElement getEditButton() {
		return editButton;
	}
    
    public WebElement getTitleField() {
		return titleField;
	}
    
    public WebElement getDescriptionField() {
		return descriptionField;
	}
    
    public WebElement getAmountField() {
		return amountField;
	}
    
    public WebElement getCommissionField() {
		return commissionField;
	}
    
    public WebElement getSaveButton() {
		return saveButton;
	}
    
//    public void clickEditButton() {
//        wait.until(ExpectedConditions.elementToBeClickable(editButton)).click();
//    }

//    public void updateTitle(String title) {
//        wait.until(ExpectedConditions.visibilityOf(titleField)).clear();
//        titleField.sendKeys(title);
//    }

//    public void updateDescription(String description) {
//        wait.until(ExpectedConditions.visibilityOf(descriptionField)).clear();
//        descriptionField.sendKeys(description);
//    }

//    public void updateAmount(String amount) {
//        wait.until(ExpectedConditions.visibilityOf(amountField)).clear();
//        amountField.sendKeys(amount);
//    }

//    public void updateCommission(String commission) {
//        wait.until(ExpectedConditions.visibilityOf(commissionField)).clear();
//        commissionField.sendKeys(commission);
//    }

//    public void saveDeal() {
//        wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();
//    }
    
}
