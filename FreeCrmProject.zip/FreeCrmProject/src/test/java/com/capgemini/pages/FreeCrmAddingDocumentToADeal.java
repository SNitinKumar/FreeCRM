package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FreeCrmAddingDocumentToADeal {

	WebDriver driver;
	
	@FindBy (xpath = "//div/input[contains(@name,'title')]")
	private WebElement addingDocumentTitle;
	
	@FindBy (xpath = "//textarea[@name='description']")
	private WebElement addingDocumentDescription;
	
	@FindBy (xpath = "//div/input[@name='file']")
	private WebElement addingDocumentFile;
	
	@FindBy (xpath = "//button[@class='ui linkedin button']")
	private WebElement addingDocumentSave;
	
	 public FreeCrmAddingDocumentToADeal(WebDriver driver) {
	        this.driver = driver;
	        PageFactory.initElements(driver, this);
	    }
	
	 public WebElement getAddingDocumentTitle() {
			return addingDocumentTitle;
		}
	 
	 public WebElement getAddingDocumentDescription() {
			return addingDocumentDescription;
		}
	 
	 public WebElement getAddingDocumentFile() {
			return addingDocumentFile;
		}
	 
	 public WebElement getAddingDocumentSave() {
			return addingDocumentSave;
		}
}
