package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class FreeCrmDeletePage {
	WebDriver driver;
	
	@FindBy (xpath = "//th[contains(text(),'Title')]")
	private WebElement titleHeading;
	
	@FindBy (xpath = "(//button/i[@class='trash icon'])[1]")
	private WebElement deleteButton;
	
	@FindBy (xpath = "//button[@class='ui red button']")
	private WebElement delete;
	
	 public FreeCrmDeletePage(WebDriver driver) {
	        this.driver = driver;
	        PageFactory.initElements(driver, this);
	    }
	 public WebElement getTitleHeading() {
			return titleHeading;
		}
	 public WebElement getDeleteButton() {
			return deleteButton;
		}
	 public WebElement getDelete() {
			return delete;
		}
	 
}
