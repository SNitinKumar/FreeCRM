package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FreeCrmInvalidDataToCreateDeal {

	@FindBy(xpath ="//button[text()='Create']")
	WebElement createDealsButton;

	@FindBy(xpath="//button[contains(.,'Save')]")
    private WebElement saveDeal;
	
	WebDriver driver;
	
	public FreeCrmInvalidDataToCreateDeal(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getCreateDealsButton() {
		return createDealsButton;
	}
	
	public WebElement getSaveDeal() {
		return saveDeal;
	}
}
