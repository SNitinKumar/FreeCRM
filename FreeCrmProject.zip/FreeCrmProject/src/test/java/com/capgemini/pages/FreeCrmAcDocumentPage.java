package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FreeCrmAcDocumentPage {

	WebDriver driver;
	
	@FindBy(xpath = "(//button/i[@class='unhide icon'])[1]")
	private WebElement optionAc;
	
	@FindBy(xpath = "(//button/i[@class='add icon'])[6]")
	private WebElement addingDocument;
	
	 public FreeCrmAcDocumentPage(WebDriver driver) {
	        this.driver = driver;
	        PageFactory.initElements(driver, this);
	    }
	 
	 public WebElement getOptionAc() {
			return optionAc;
		}
	 
	 public WebElement getAddingDocument() {
			return addingDocument;
		}
}
