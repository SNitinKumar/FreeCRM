package com.capgemini.tests;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.capgemini.pages.FreeCrmDashboard;
import com.capgemini.pages.FreeCrmDealPage;
import com.capgemini.pages.FreeCrmLoginPage;
import com.capgemini.parameters.ExcelReader;
import com.capgemini.utils.Screenshots;

public class TC_001 extends BaseReport {
	WebDriver driver;
	WebDriverWait wait;
	String screenshotPath;
	static String baseUrl;
	FreeCrmLoginPage freeCrmLoginPage;
	FreeCrmDealPage freeCrmDealPage;
	FreeCrmDashboard freeCrmDashboard;
	static String excelPath;

	@BeforeTest
	public void setUpTest() {
		baseUrl = "https://freecrm.com/";
		excelPath = "src/test/resources/ExcelData/TestData.xlsx";
	}

	@BeforeClass
	public void setUp() {
		driver = new ChromeDriver();
		driver.navigate().to(baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		freeCrmLoginPage = new FreeCrmLoginPage(driver);
		freeCrmDealPage = new FreeCrmDealPage(driver);
	}

	/*
	 * Created By : Sindiri Nitin Kumar
	 * Reviewed By : Richa Singh
	 * Test scenario: 
	 */

	@Test(priority = 1)
	public void testLogin() throws Exception {
		
		String email = ExcelReader.getCellData(excelPath, "User_Details", 1, 0);
		String password = ExcelReader.getCellData(excelPath, "User_Details", 1, 1);

		// Step 1: Click on Login link
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getLoginPage())).click();
		Reporter.log("Clicked on Login", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "LoginLinkClicked");
		generateReportWithScreenshot("Click on the login", screenshotPath);

		// Step 2: Enter email
		wait.until(ExpectedConditions.visibilityOf(freeCrmLoginPage.getEmail())).sendKeys(email);
		Reporter.log("Entered Mail", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "UserEmailIdEntered");
		generateReportWithScreenshot("Entered Mail", screenshotPath);

		// Step 3: Enter password
		wait.until(ExpectedConditions.visibilityOf(freeCrmLoginPage.getPassword())).sendKeys(password);
		Reporter.log("Entered Password", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "UserPasswordEntered");
		generateReportWithScreenshot("Entered Password", screenshotPath);

		// Step 4: Click on Login button
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getLoginBtn())).click();
		Reporter.log("Clicked on Login Button", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "LoginButtonClicked");
		generateReportWithScreenshot("Clicked on Login Button", screenshotPath);

		// Step 5: Navigate to Deals section
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getDealsLink())).click();
		Reporter.log("Clicked on Deals", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "DealsButtonClicked");
		generateReportWithScreenshot("Clicked on Deals", screenshotPath);
	}

	/*
	 * Created By : Sindiri Nitin Kumar
	 * Reviewed By : Richa Singh
	 * Test scenario:
	 */

	@Test(priority = 2)
	public void testDeals() throws Exception {
		String titleName = ExcelReader.getCellData(excelPath, "Deals", 1, 0);
		String description = ExcelReader.getCellData(excelPath, "Deals", 1, 1);
		String amount = ExcelReader.getCellData(excelPath, "Deals", 1, 2);
		String commissions = ExcelReader.getCellData(excelPath, "Deals", 1, 3);

		// Step 6: Click on Create Deal button
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmDealPage.getCreateDealButton())).click();
		Reporter.log("Create Deal Button is clicked", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "DealButtonIsClicked");
		generateReportWithScreenshot("Create Deal Button is clicked", screenshotPath);

		// Step 7: Enter Title
		wait.until(ExpectedConditions.visibilityOf(freeCrmDealPage.getTitleName())).sendKeys(titleName);
		Reporter.log("Entered Title", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "TitleEntered");
		generateReportWithScreenshot("Entered Title", screenshotPath);

		// Step 8: Enter Description
		wait.until(ExpectedConditions.visibilityOf(freeCrmDealPage.getDescription())).sendKeys(description);
		Reporter.log("Entered Description", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "DescriptionEntered");
		generateReportWithScreenshot("Entered Description", screenshotPath);

		// Step 9: Enter Amount
		wait.until(ExpectedConditions.visibilityOf(freeCrmDealPage.getAmountUsd())).sendKeys(amount);
		Reporter.log("Entered Amount", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "AmountEntered");
		generateReportWithScreenshot("Entered Amount", screenshotPath);

		// Step 10: Enter Commissions
		wait.until(ExpectedConditions.visibilityOf(freeCrmDealPage.getCommissions())).sendKeys(commissions);
		Reporter.log("Entered Commissions", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "CommissionsEntered");
		generateReportWithScreenshot("Entered Commissions", screenshotPath);

		// Step 11: Select Stage
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmDealPage.getStages())).click();
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmDealPage.getStageDropdown())).click();
		Reporter.log("Entered Stages", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "StageDropdownEntered");
		generateReportWithScreenshot("Entered Stages", screenshotPath);

		// Step 12: Select Type
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmDealPage.getTypes())).click();
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmDealPage.getTypeDropdown())).click();
		Reporter.log("Entered Types", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "TypeDropdownEntered");
		generateReportWithScreenshot("Entered Types", screenshotPath);

		// Step 13: Save the Deal
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmDealPage.getSaveDeal())).click();
		Reporter.log("Clicked on SaveDeals", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "SavedDealButtonClicked");
		generateReportWithScreenshot("Clicked on SaveDeals", screenshotPath);

		// Step 14: Navigate back to Deals
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmDealPage.getDealsBtn())).click();
		Reporter.log("Clicked on Deals", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "DealsButtonClicked");
		generateReportWithScreenshot("Clicked on Deals", screenshotPath);
	}

	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit();
			Reporter.log("Browser closed successfully", true);
		}
		Reporter.log("Test completed successfully", true);
	}
}
