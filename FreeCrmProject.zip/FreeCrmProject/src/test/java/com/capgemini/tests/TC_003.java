package com.capgemini.tests;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.capgemini.pages.FreeCrmDeletePage;
import com.capgemini.pages.FreeCrmLoginPage;
import com.capgemini.parameters.JsonReader;
import com.capgemini.utils.Screenshots;

public class TC_003 extends BaseReport {

	WebDriver driver;
	WebDriverWait wait;
	static String baseUrl;
	FreeCrmLoginPage freeCrmLoginPage;
	FreeCrmDeletePage freeCrmDeletePage;
	static String excelPath;
	String screenshotPath;

	@BeforeTest
	public void setUpTest() {
		baseUrl = "https://freecrm.com/";
	}

	@BeforeClass
	public void setUp() {
		driver = new ChromeDriver();
		driver.navigate().to(baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		freeCrmLoginPage = new FreeCrmLoginPage(driver);
		freeCrmDeletePage = new FreeCrmDeletePage(driver);
	}

	/*
	 * Created By : Sindiri Nitin Kumar
	 * Reviewed By : Richa Singh
	 * Test scenario:
	 */
	
	@Test(priority = 1)
	public void testLogin() throws Exception {

		String[] creds = JsonReader.getJsonData("src/test/resources/JsonData/TestData.json","email","password");
		String email = creds[0];
		String password = creds[1];

		// Step 1: Click on Login link
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getLoginPage())).click();
		Reporter.log("Clicked on the Login", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "LoginLinkClicked");
		generateReportWithScreenshot("Click on the login", screenshotPath);

		// Step 2: Enter email
		wait.until(ExpectedConditions.visibilityOf(freeCrmLoginPage.getEmail())).sendKeys(email);
		Reporter.log("Entered Mail", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "UserEmailIdEntered");
		generateReportWithScreenshot("Entered Mail", screenshotPath);

		// Step 3: Enter password
		wait.until(ExpectedConditions.visibilityOf(freeCrmLoginPage.getPassword())).sendKeys(password);
		Reporter.log("Entered Password", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "UserPasswordEntered");
		generateReportWithScreenshot("Entered Password", screenshotPath);

		// Step 4: Click on Login button
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getLoginBtn())).click();
		Reporter.log("Clicked on Login Button", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "LoginButtonClicked");
		generateReportWithScreenshot("Clicked on Login Button", screenshotPath);

		// Step 5: Navigate to Deals section
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getDealsLink())).click();
		Reporter.log("Clicked on Deals", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "DealsButtonClicked");
		generateReportWithScreenshot("Clicked on Deals", screenshotPath);
	}

	/*
	 * Created By : Sindiri Nitin Kumar
	 * Reviewed By : Richa Singh
	 * Test scenario:
	 */
	
	@Test(priority = 2)
	public void testDelete() throws Exception {
		// Step 6: Click on a deal title to open it
		if (freeCrmDeletePage.getTitleHeading().isDisplayed()) {
			wait.until(ExpectedConditions.elementToBeClickable(freeCrmDeletePage.getTitleHeading())).click();
			screenshotPath = Screenshots.takeScreenShot(driver, "TitleHeadingClicked");
			generateReportWithScreenshot("Clicked on TitleHeading", screenshotPath);
			test.pass("Clicked on TitleHeading" + freeCrmDeletePage);
			Assert.assertTrue(true, "Title heading clicked successfully.");
		} else {
			screenshotPath = Screenshots.takeScreenShot(driver, "TitleHeadingNotFound");
			generateReportWithScreenshot("Title heading not found", screenshotPath);
			test.fail("Title heading not found"+freeCrmDeletePage);
			Assert.fail("Title heading not found.");
		}
		
		// Step 7: Click on a deal title to open it
				if (freeCrmDeletePage.getTitleHeading().isDisplayed()) {
					wait.until(ExpectedConditions.elementToBeClickable(freeCrmDeletePage.getTitleHeading())).click();
					screenshotPath = Screenshots.takeScreenShot(driver, "TitleHeadingClickedAgain");
					generateReportWithScreenshot("Clicked on TitleHeading Again", screenshotPath);
					test.pass("Clicked on TitleHeading Again" + freeCrmDeletePage);
					Assert.assertTrue(true, "Title heading clicked successfully.");
				} else {
					screenshotPath = Screenshots.takeScreenShot(driver, "TitleHeadingNotFound");
					generateReportWithScreenshot("Title heading not found", screenshotPath);
					test.fail("Title heading not found"+freeCrmDeletePage);
					Assert.fail("Title heading not found.");
				}

		// Step 8: Click on Delete button
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmDeletePage.getDeleteButton())).click();
		Reporter.log("Clicked on DeleteButton", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "DeleteButtonClicked");
		generateReportWithScreenshot("Clicked on DeleteButton", screenshotPath);

		// Step 9: Confirm deletion
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmDeletePage.getDelete())).click();
		Reporter.log("Clicked on Delete", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "DeleteClicked");
		generateReportWithScreenshot("Clicked on Delete", screenshotPath);

		// Step 10: Navigate back to Deals
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getDealsLink())).click();
		Reporter.log("Clicked on Deals", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "DealsButtonClicked");
		generateReportWithScreenshot("Clicked on Deals", screenshotPath);

	}

	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit();
			Reporter.log("Browser closed successfully", true);
		}
		Reporter.log("Test completed successfully", true);
	}
}
