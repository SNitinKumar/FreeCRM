package com.capgemini.tests;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.capgemini.pages.FreeCrmDeletePage;
import com.capgemini.pages.FreeCrmFiltersForDeals;
import com.capgemini.pages.FreeCrmLoginPage;
import com.capgemini.parameters.JsonReader;
import com.capgemini.utils.Screenshots;

public class TC_004 extends BaseReport {

	WebDriver driver;
	WebDriverWait wait;
	static String baseUrl;
	FreeCrmLoginPage freeCrmLoginPage;
	FreeCrmDeletePage freeCrmDeletePage;
	FreeCrmFiltersForDeals freeCrmFiltersForDeals;
	static String excelPath;
	String screenshotPath;

	@BeforeTest
	public void setUpTest() {
		baseUrl = "https://freecrm.com/";
	}

	@BeforeClass
	public void setUp() {
		driver = new ChromeDriver();
		driver.navigate().to(baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		freeCrmLoginPage = new FreeCrmLoginPage(driver);
		freeCrmFiltersForDeals = new FreeCrmFiltersForDeals(driver);
	}

	/*
	 * Created By : Sindiri Nitin Kumar
	 * Reviewed By : Richa Singh
	 * Test scenario:
	 */
	
	@Test
	public void testLogin() throws Exception {

		String[] creds = JsonReader.getJsonData("src/test/resources/JsonData/TestData.json","email","password");
		String email = creds[0];
		String password = creds[1];

		// Step 1: Click on Login link
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getLoginPage())).click();
		Reporter.log("Clicked on the Login", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "LoginLinkClicked");
		generateReportWithScreenshot("Click on the login", screenshotPath);

		// Step 2: Enter email
		wait.until(ExpectedConditions.visibilityOf(freeCrmLoginPage.getEmail())).sendKeys(email);
		Reporter.log("Entered Mail", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "UserEmailIdEntered");
		generateReportWithScreenshot("Entered Mail", screenshotPath);

		// Step 3: Enter password
		wait.until(ExpectedConditions.visibilityOf(freeCrmLoginPage.getPassword())).sendKeys(password);
		Reporter.log("Entered Password", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "UserPasswordEntered");
		generateReportWithScreenshot("Entered Password", screenshotPath);

		// Step 4: Click on Login button
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getLoginBtn())).click();
		Reporter.log("Clicked on Login Button", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "LoginButtonClicked");
		generateReportWithScreenshot("Clicked on Login Button", screenshotPath);

		// Step 5: Navigate to Deals section
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getDealsLink())).click();
		Reporter.log("Clicked on Deals", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "DealsButtonClicked");
		generateReportWithScreenshot("Clicked on Deals", screenshotPath);
	}

	/*
	 * Created By : Sindiri Nitin Kumar
	 * Reviewed By : Richa Singh
	 * Test scenario:
	 */
	
	@Test(dependsOnMethods = "testLogin")
	public void testFilters() throws Exception {
		// Step 6: Click on Show Filters
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmFiltersForDeals.getShowFilters())).click();
		Reporter.log("Clicked on ShowFilters", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "ShowFiltersButtonClicked");
		generateReportWithScreenshot("Clicked on ShowFilters", screenshotPath);

		// Step 7: Click on Search field
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmFiltersForDeals.getSearch())).click();
		Reporter.log("Clicked on Search", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "SearchClicked");
		generateReportWithScreenshot("Clicked on Search", screenshotPath);

		// Step 8: Click on Search Dropdown
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmFiltersForDeals.getSearchDropdown())).click();
		Reporter.log("Clicked on SearchDropdown", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "SearchDropdownClicked");
		generateReportWithScreenshot("Clicked on SearchDropdown", screenshotPath);

		// Step 9: Click on Operator field
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmFiltersForDeals.getOperator())).click();
		Reporter.log("Clicked on Operator", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "OperatorClicked");
		generateReportWithScreenshot("Clicked on Operator", screenshotPath);

		// Step 10: Click on Operator Dropdown
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmFiltersForDeals.getOperatorDropdown())).click();
		Reporter.log("Clicked on OperatorDropdown", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "OperatorDropdownClicked");
		generateReportWithScreenshot("Clicked on OperatorDropdown", screenshotPath);

		// Step 11: Click on Value field
		wait.until(ExpectedConditions.visibilityOf(freeCrmFiltersForDeals.getValue())).click();
		Reporter.log("Clicked on ValueButton", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "ValueButtonClicked");
		generateReportWithScreenshot("Clicked on ValueButton", screenshotPath);

		// Step 12: Enter value to filter (e.g., "Laptops")
		freeCrmFiltersForDeals.getValue().sendKeys("Laptops");
		Reporter.log("Entered Value", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "ValueEntered");
		generateReportWithScreenshot("Entered Value", screenshotPath);

		// Step 13: Click on Filter button to apply filters
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmFiltersForDeals.getFilter())).click();
		Reporter.log("Clicked on Search Filter", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "SearchFilterClicked");
		generateReportWithScreenshot("Clicked on Search Filter", screenshotPath);
	}

	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit();
			Reporter.log("Browser closed successfully", true);
		}
		Reporter.log("Test completed successfully", true);
	}
}
