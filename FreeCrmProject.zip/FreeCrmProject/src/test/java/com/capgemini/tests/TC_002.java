package com.capgemini.tests;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.capgemini.pages.FreeCrmDeletePage;
import com.capgemini.pages.FreeCrmEditPage;
import com.capgemini.pages.FreeCrmLoginPage;
import com.capgemini.parameters.ExcelReader;
import com.capgemini.utils.Screenshots;

public class TC_002 extends BaseReport {
	WebDriver driver;
	WebDriverWait wait;
	static String baseUrl;
	FreeCrmLoginPage freeCrmLoginPage;
	FreeCrmEditPage freeCrmEditPage;
	FreeCrmDeletePage freeCrmDeletePage;
	static String excelPath;
	String screenshotPath;

	@BeforeTest
	public void setUpTest() {
		baseUrl = "https://freecrm.com/";
		excelPath = "src/test/resources/ExcelData/TestData.xlsx";
	}

	@BeforeClass
	public void setUp() {
		driver = new ChromeDriver();
		driver.navigate().to(baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		freeCrmLoginPage = new FreeCrmLoginPage(driver);
		freeCrmEditPage = new FreeCrmEditPage(driver);
		freeCrmDeletePage = new FreeCrmDeletePage(driver);
	}

	/*
	 * Created By : Sindiri Nitin Kumar
	 * Reviewed By : Richa Singh
	 * Test scenario:
	 */

	@Test(priority = 1)
	public void testLogin() throws Exception {

		String email = ExcelReader.getCellData(excelPath, "User_Details", 1, 0);
		String password = ExcelReader.getCellData(excelPath, "User_Details", 1, 1);

		// Step 1: Click on Login link
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getLoginPage())).click();
		Reporter.log("Clicked on the Login", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "LoginLinkClicked");
		generateReportWithScreenshot("Click on the login", screenshotPath);

		// Step 2: Enter email
		wait.until(ExpectedConditions.visibilityOf(freeCrmLoginPage.getEmail())).sendKeys(email);
		Reporter.log("Entered Mail", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "UserEmailIdEntered");
		generateReportWithScreenshot("Entered Mail", screenshotPath);

		// Step 3: Enter password
		wait.until(ExpectedConditions.visibilityOf(freeCrmLoginPage.getPassword())).sendKeys(password);
		Reporter.log("Entered Password", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "UserPasswordEntered");
		generateReportWithScreenshot("Entered Password", screenshotPath);

		// Step 4: Click on Login button
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getLoginBtn())).click();
		Reporter.log("Clicked on Login Button", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "LoginButtonClicked");
		generateReportWithScreenshot("Clicked on Login Button", screenshotPath);

		// Step 5: Navigate to Deals section
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getDealsLink())).click();
		Reporter.log("Clicked on Deals", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "DealsButtonClicked");
		generateReportWithScreenshot("Clicked on Deals", screenshotPath);
	}

	/*
	 * Created By : Sindiri Nitin Kumar
	 * Reviewed By : Richa Singh
	 * Test scenario:
	 */

	@Test(priority = 2)
	public void testEdits() throws Exception {

		// Step 6: Click on the deal title to open it
		if (freeCrmDeletePage.getTitleHeading().isDisplayed()) {
			wait.until(ExpectedConditions.elementToBeClickable(freeCrmDeletePage.getTitleHeading())).click();
			screenshotPath = Screenshots.takeScreenShot(driver, "TitleHeadingClicked");
			generateReportWithScreenshot("Clicked on TitleHeading", screenshotPath);
			test.pass("Clicked on TitleHeading" + freeCrmDeletePage);
			Assert.assertTrue(true, "Title heading clicked successfully.");
		} else {
			screenshotPath = Screenshots.takeScreenShot(driver, "TitleHeadingNotFound");
			generateReportWithScreenshot("Title heading not found", screenshotPath);
			test.fail("Title heading not found"+freeCrmDeletePage);
			Assert.fail("Title heading not found.");
		}

		// Step 7: Click on a deal title to open it
		if (freeCrmDeletePage.getTitleHeading().isDisplayed()) {
			wait.until(ExpectedConditions.elementToBeClickable(freeCrmDeletePage.getTitleHeading())).click();
			screenshotPath = Screenshots.takeScreenShot(driver, "TitleHeadingClickedAgain");
			generateReportWithScreenshot("Clicked on TitleHeading Again", screenshotPath);
			test.pass("Clicked on TitleHeading Again" + freeCrmDeletePage);
			Assert.assertTrue(true, "Title heading clicked successfully.");
		} else {
			screenshotPath = Screenshots.takeScreenShot(driver, "TitleHeadingNotFound");
			generateReportWithScreenshot("Title heading not found", screenshotPath);
			test.fail("Title heading not found"+freeCrmDeletePage);
			Assert.fail("Title heading not found.");
		}

		// Step 8: Click on Edit button
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmEditPage.getEditButton())).click();
		Reporter.log("Clicked on EditButton", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "EditButtonClicked");
		generateReportWithScreenshot("Clicked on EditButton", screenshotPath);

		// Step 9: Update the title field
		wait.until(ExpectedConditions.visibilityOf(freeCrmEditPage.getTitleField())).click();
		freeCrmEditPage.getTitleField().sendKeys(" And Washing Machine");
		Reporter.log("Updated Title", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "UpdatedTitleEntered");
		generateReportWithScreenshot("Updated Title", screenshotPath);

		// Step 10: Update the description field
		wait.until(ExpectedConditions.visibilityOf(freeCrmEditPage.getDescriptionField())).click();
		freeCrmEditPage.getDescriptionField().sendKeys(" And Bosch");
		Reporter.log("Updated Description", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "UpdatedDescriptionEntered");
		generateReportWithScreenshot("Updated Description", screenshotPath);

		// Step 11: Update the amount field
		wait.until(ExpectedConditions.visibilityOf(freeCrmEditPage.getAmountField())).click();
		freeCrmEditPage.getAmountField().sendKeys("0");
		Reporter.log("Updated Amount", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "UpdatedAmountEntered");
		generateReportWithScreenshot("Updated Amount", screenshotPath);

		// Step 12: Update the commission field
		wait.until(ExpectedConditions.visibilityOf(freeCrmEditPage.getCommissionField())).click();
		freeCrmEditPage.getCommissionField().sendKeys("0");
		Reporter.log("Updated Commission", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "UpdatedCommissionEntered");
		generateReportWithScreenshot("Updated Commission", screenshotPath);

		// Step 13: Click on Save button
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmEditPage.getSaveButton())).click();
		Reporter.log("Clicked on SaveDeal", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "SaveDealClicked");
		generateReportWithScreenshot("Clicked on SaveDeal", screenshotPath);

		// Step 14: Navigate back to Deals
		wait.until(ExpectedConditions.elementToBeClickable(freeCrmLoginPage.getDealsLink())).click();
		Reporter.log("Clicked on Deals", true);
		Assert.assertTrue(true);
		screenshotPath = Screenshots.takeScreenShot(driver, "DealsButtonClicked");
		generateReportWithScreenshot("Clicked on Deals", screenshotPath);
	}

	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit();
			Reporter.log("Browser closed successfully", true);
		}
		Reporter.log("Test completed successfully", true);
	}
}
